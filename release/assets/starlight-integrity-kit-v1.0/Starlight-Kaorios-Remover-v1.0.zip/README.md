# Starlight Kaorios Remover v1.0

A **recovery-flashable** ZIP that removes the **Kaorios Toolbox** integrity
module from any device — the Starlight ColorOS 17 sweetin ROM, or any other
phone where the module was installed.

Flash it in **OrangeFox / TWRP recovery → Install**. It is safe on any device:
only `kaorios` / `kousei` / `kaoripif` paths are touched, nothing is wiped and
no partition is flashed.

## What it removes

| # | Target |
|---|---|
| 1 | The KernelSU / KernelSU-Next module (`starlight_kaorios_integrity` and any module whose name or payload matches kaorios/kousei), removed through `ksud module remove` when available |
| 2 | The module's self-mounted `/system` overlay work dirs (`/data/adb/starlight_integrity`) |
| 3 | Scratch copies (`/data/local/tmp/old_kaorios_module`, `kaorios_work`, …) |
| 4 | Packages `com.kousei.kaorios` (Toolbox) and `com.kaorios.patcher` (Patcher) — app dirs, user data, profiles, graphicsstats, splash art, package cache |
| 5 | Baked-in payload in `/system`, `/system_ext`, `/product`, `/vendor`, `/odm`: `priv-app/KaoriosToolbox`, `lib{,64}/libkaoripif*.so`, `etc/permissions/com.kousei.kaorios.xml` (best effort — EROFS is read-only) |
| 6 | Leftover `*Kaorios*` / `*KaoriosPatcher*` zips, APKs and logs in internal storage |
| 7 | KSU staging leftovers in `/data/adb/modules_update` and `/data/adb/ksu/modules` |

## Requirements
- A recovery with a shell (OrangeFox R12, TWRP, etc.). Root is automatic in recovery.
- **Do not** flash this from the KernelSU/Magisk manager — it is a recovery
  package, not a module.

## Install
```
OrangeFox / TWRP  ->  Install  ->  choose Starlight-Kaorios-Remover-v1.0.zip
```
Watch the recovery console: it prints every removed item and a final count.
Then **reboot into your system**.

## Manual / adb alternative (no flashing)
If you are already in recovery with adb, or you just want to run it without
installing:
```sh
adb shell sh /tmp/kaorios_cleanup.sh
```
`cleanup.sh` is also shipped at the root of this ZIP, so you can push it:
```sh
adb push cleanup.sh /tmp/kaorios_cleanup.sh
adb shell sh /tmp/kaorios_cleanup.sh
```

## Note after removal
If the Kaorios module was active, the *running* system may still have the
patched `framework.jar` / `services.jar` classes loaded in memory. A reboot
into the system is required to fully restore stock behaviour.

Also: **do not** force `ro.boot.selinux=enforcing` on a ported ROM that lacks
the matching vendor sepolicy allow rules — system_server will restart-loop and
the device will land in recovery. The Kaorios `props.sh` that did this was
removed on 2026-11-13 for exactly that reason.

## Files
| Path | What |
|---|---|
| `Starlight-Kaorios-Remover-v1.0.zip` | The flashable package |
| `cleanup.sh` | Standalone cleanup logic (also embedded in the installer) |
| `update-binary.in` | Recovery installer template |
| `updater-script` | Recovery fallback script |
| `build.sh` | Rebuilds the ZIP from the sources above |
| `manifest.yaml` | Change / verification record |

## Credits
- Cleanup design and verification: Starlight Ports (sweetin ColorOS 17 port)
- Removal procedure derived from the live removal on 2026-11-14.
