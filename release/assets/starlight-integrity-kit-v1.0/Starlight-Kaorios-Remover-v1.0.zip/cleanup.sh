#!/system/bin/sh
# =============================================================================
# Starlight Kaorios Remover — cleanup logic
#
# Removes every trace of the Kaorios Toolbox integrity module from a device.
# Runs as root inside ANY recovery (OrangeFox / TWRP / ...) or from an adb
# shell in recovery:
#
#     adb shell sh /tmp/kaorios_cleanup.sh
#
# Safe on any device: only kaorios / kousei / kaoripif paths are touched.
# Nothing outside those is modified, and nothing is wiped.
# =============================================================================

COUNT=0

say() { echo "$1"; }

removed() {
    COUNT=$((COUNT + 1))
    say "  [x] $1"
}

say ""
say "== Starlight Kaorios Remover =="

# -----------------------------------------------------------------------------
# 1. KernelSU / KernelSU-Next modules (including the self-mounted /system
#    overlay module "starlight_kaorios_integrity")
# -----------------------------------------------------------------------------
MODROOT=/data/adb/modules
if [ -d "$MODROOT" ]; then
    for d in "$MODROOT"/*; do
        [ -d "$d" ] || continue
        name=$(basename "$d")
        hit=""
        case "$name" in
            *aorios*|*Aorios*|*ousei*|*Ousei*) hit="name" ;;
        esac
        if [ -z "$hit" ]; then
            if [ -e "$d/system/priv-app/KaoriosToolbox" ] ||
               [ -e "$d/system/lib64/libkaoripif.so" ] ||
               [ -e "$d/system/lib/libkaoripif.so" ] ||
               [ -e "$d/system/etc/permissions/com.kousei.kaorios.xml" ]; then
                hit="payload"
            fi
        fi
        if [ -n "$hit" ]; then
            if [ -x /data/adb/ksud ]; then
                /data/adb/ksud module remove "$name" >/dev/null 2>&1
            fi
            if [ -d "$d" ]; then
                rm -rf "$d" 2>/dev/null
            fi
            if [ -d "$d" ]; then
                say "  [!] could not remove module $name"
            else
                removed "module $name"
            fi
        fi
    done
fi

# -----------------------------------------------------------------------------
# 2. Overlay work dirs + scratch copies
# -----------------------------------------------------------------------------
for p in \
    /data/adb/starlight_integrity \
    /data/adb/kaorios \
    /data/adb/kaoripif \
    /data/adb/kaorios_integrity \
    /data/local/tmp/old_kaorios_module \
    /data/local/tmp/kaorios_toolbox \
    /data/local/tmp/kaorios_work
do
    if [ -e "$p" ]; then
        rm -rf "$p" 2>/dev/null
        if [ -e "$p" ]; then
            say "  [!] could not remove $p"
        else
            removed "dir $p"
        fi
    fi
done

# -----------------------------------------------------------------------------
# 3. Packages: com.kousei.kaorios (Toolbox) + com.kaorios.patcher (Patcher)
# -----------------------------------------------------------------------------
for p in com.kousei.kaorios com.kaorios.patcher; do
    for pat in \
        "/data/app/$p" "/data/app/$p"* "/data/app/*/$p" "/data/app/*/$p"* \
        "/data/app-*/*/$p" "/data/app-*/*/$p"* \
        "/data/user/0/$p" "/data/user_de/0/$p" \
        "/data/misc/profiles/cur/0/$p" "/data/misc/profiles/ref/0/$p" \
        "/data/system/graphicsstats/*/$p" \
        "/data/system/splash/startingsurface/$p"* \
        "/data/system/package_cache/*/$p"* \
        "/data/system/packages.xml" "/data/system/packages.list"
    do
        for f in $pat; do
            [ -e "$f" ] || continue
            case "$f" in
                /data/system/packages.xml|/data/system/packages.list) continue ;;
            esac
            rm -rf "$f" 2>/dev/null
            [ -e "$f" ] || removed "$f"
        done
    done
done

# -----------------------------------------------------------------------------
# 4. Payload baked into a partition (best effort — EROFS is read-only)
# -----------------------------------------------------------------------------
for base in /system /system_ext /product /vendor /odm /my_product /my_stock; do
    [ -d "$base" ] || continue
    for f in \
        "$base/priv-app/KaoriosToolbox" \
        "$base/lib64/libkaoripif.so" "$base/lib/libkaoripif.so" \
        "$base/lib64/libkaoripif_diagnostic.so" "$base/lib/libkaoripif_diagnostic.so" \
        "$base/etc/permissions/com.kousei.kaorios.xml"
    do
        if [ -e "$f" ]; then
            if rm -rf "$f" 2>/dev/null && [ ! -e "$f" ]; then
                removed "$f"
            else
                say "  [i] read-only, not removable here: $f"
            fi
        fi
    done
done

# -----------------------------------------------------------------------------
# 5. Leftover zips / apks / logs in internal storage
# -----------------------------------------------------------------------------
for d in /sdcard/Download /storage/emulated/0/Download /data/media/0/Download \
         /sdcard /storage/emulated/0
do
    [ -d "$d" ] || continue
    for f in "$d"/*aorios* "$d"/*Aorios* "$d"/*ousei* "$d"/*kaoripif*; do
        [ -e "$f" ] || continue
        [ -d "$f" ] && continue
        # never delete this remover package itself
        case "$(basename "$f")" in
            *[Rr]emover*) continue ;;
        esac
        [ -n "$ZIPFILE" ] && [ "$f" = "$ZIPFILE" ] && continue
        rm -f "$f" 2>/dev/null
        [ -e "$f" ] || removed "$f"
    done
done

# -----------------------------------------------------------------------------
# 6. Staging leftovers
# -----------------------------------------------------------------------------
for pat in \
    "/data/adb/modules_update/*aorios*" "/data/adb/modules_update/*ousei*" \
    "/data/adb/ksu/modules/*aorios*" "/data/adb/ksu/modules/*ousei*"
do
    for f in $pat; do
        [ -e "$f" ] || continue
        rm -rf "$f" 2>/dev/null
        [ -e "$f" ] || removed "$f"
    done
done

# -----------------------------------------------------------------------------
say ""
if [ "$COUNT" = "0" ]; then
    say "== nothing to remove — Kaorios was not installed on this device =="
else
    say "== done: $COUNT item(s) removed =="
fi
say "Reboot to finish (a running system may still hold patched classes)."
say ""
exit 0
